#!/bin/sh
#
#BSUB   -J reduce_scatter_block
#BSUB   -o res.txt.%J
#BSUB   -e res.txt.%J
#BSUB   -W 2:00
#BSUB   -nnodes 49

module unload spectrum-mpi xalt darshan-runtime
module load gcc/6.4.0
module load cuda/10.1.243
module use /sw/summit/ums/ompix/gcc/6.4.0/modules
module load ucx/1.7.0
module load openmpi/master

# TJN: HACK avoid problems with broken --nolocal/:NOLOCAL
export MY_HOSTFILE=/tmp/my-hostfile.$$
/gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/hack_fqn_nolocal_hostfile.sh $LSB_DJOB_HOSTFILE  $MY_HOSTFILE

###
# TJN: HACK force passing of 'mpirun -x LD_LIBRARY_PATH' due to odd lib search problem
#      not resolving stdc++ lib on compute nodes
#
# What we get is effectively...
#  mpirun \
#    -x LD_LIBRARY_PATH=/sw/summit/gcc/6.4.0/lib64:/sw/peak/gcc/6.4.0/lib64:$LD_LIBRARY_PATH \
#     ...  ./IMB-MPI1 reduce_scatter_block
#
# But only need to pass service node's env where ldd resolves properly...
#  mpirun \
#    -x LD_LIBRARY_PATH \
#      ...
#    ./IMB-MPI1 reduce_scatter_block
###

#  0 2 ranks
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_2ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_2ranks_run1.out

#  1 2 ranks
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_2ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_2ranks_run1.out

#  2 2 ranks
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_2ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_2ranks_run1.out

#  3 2 ranks
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_2ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_2ranks_run1.out

#  4 2 ranks
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_2ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_2ranks_run1.out

#  0 4 ranks
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_4ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_4ranks_run1.out

#  1 4 ranks
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_4ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_4ranks_run1.out

#  2 4 ranks
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_4ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_4ranks_run1.out

#  3 4 ranks
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_4ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_4ranks_run1.out

#  4 4 ranks
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_4ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 4 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_4ranks_run1.out

#  0 8 ranks
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_8ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_8ranks_run1.out

#  1 8 ranks
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_8ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_8ranks_run1.out

#  2 8 ranks
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_8ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_8ranks_run1.out

#  3 8 ranks
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_8ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_8ranks_run1.out

#  4 8 ranks
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_8ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 8 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_8ranks_run1.out

#  0 16 ranks
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_16ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_16ranks_run1.out

#  1 16 ranks
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_16ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_16ranks_run1.out

#  2 16 ranks
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_16ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_16ranks_run1.out

#  3 16 ranks
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_16ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_16ranks_run1.out

#  4 16 ranks
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_16ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 16 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_16ranks_run1.out

#  0 32 ranks
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_32ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_32ranks_run1.out

#  1 32 ranks
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_32ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_32ranks_run1.out

#  2 32 ranks
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_32ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_32ranks_run1.out

#  3 32 ranks
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_32ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_32ranks_run1.out

#  4 32 ranks
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_32ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 32 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_32ranks_run1.out

#  0 64 ranks
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_64ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_64ranks_run1.out

#  1 64 ranks
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_64ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_64ranks_run1.out

#  2 64 ranks
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_64ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_64ranks_run1.out

#  3 64 ranks
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_64ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_64ranks_run1.out

#  4 64 ranks
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_64ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 64 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_64ranks_run1.out

#  0 128 ranks
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_128ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_128ranks_run1.out

#  1 128 ranks
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_128ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_128ranks_run1.out

#  2 128 ranks
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_128ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_128ranks_run1.out

#  3 128 ranks
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_128ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_128ranks_run1.out

#  4 128 ranks
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_128ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 128 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_128ranks_run1.out

#  0 256 ranks
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_256ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_256ranks_run1.out

#  1 256 ranks
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_256ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_256ranks_run1.out

#  2 256 ranks
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_256ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_256ranks_run1.out

#  3 256 ranks
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_256ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_256ranks_run1.out

#  4 256 ranks
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_256ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 256 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_256ranks_run1.out

#  0 512 ranks
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_512ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_512ranks_run1.out

#  1 512 ranks
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_512ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_512ranks_run1.out

#  2 512 ranks
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_512ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_512ranks_run1.out

#  3 512 ranks
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_512ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_512ranks_run1.out

#  4 512 ranks
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_512ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 512 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_512ranks_run1.out

#  0 1024 ranks
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_1024ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_1024ranks_run1.out

#  1 1024 ranks
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_1024ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_1024ranks_run1.out

#  2 1024 ranks
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_1024ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_1024ranks_run1.out

#  3 1024 ranks
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_1024ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_1024ranks_run1.out

#  4 1024 ranks
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_1024ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 1024 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_1024ranks_run1.out

#  0 2048 ranks
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_2048ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/0_2048ranks_run1.out

#  1 2048 ranks
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_2048ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/1_2048ranks_run1.out

#  2 2048 ranks
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_2048ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/2_2048ranks_run1.out

#  3 2048 ranks
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_2048ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/3_2048ranks_run1.out

#  4 2048 ranks
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_2048ranks_run0.out
mpirun -x LD_LIBRARY_PATH --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_reduce_scatter_block_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/IMB/mpi-benchmarks/IMB-MPI1 -npmin 2048 reduce_scatter_block  >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/reduce_scatter_block/4_2048ranks_run1.out


# TJN: HACK avoid problems with broken --nolocal/:NOLOCAL
rm -f $MY_HOSTFILE

