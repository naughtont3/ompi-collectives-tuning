#!/bin/sh
#
#BSUB   -J alltoallv
#BSUB   -o res.txt.%J
#BSUB   -e res.txt.%J
#BSUB   -W 2:00
#BSUB   -nnodes 49

module unload spectrum-mpi xalt darshan-runtime
module load gcc/6.4.0
module load cuda/10.1.243
module use /sw/summit/ums/ompix/gcc/6.4.0/modules
module load ucx/1.7.0
module load openmpi/master

# TJN: HACK avoid problems with broken --nolocal/:NOLOCAL
export MY_HOSTFILE=/tmp/my-hostfile.$$
/gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/hack_fqn_nolocal_hostfile.sh $LSB_DJOB_HOSTFILE  $MY_HOSTFILE

# #  0 2 ranks
# mpirun --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_2ranks_run0.out
# mpirun --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_2ranks_run1.out
# 
# #  1 2 ranks
# mpirun --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_2ranks_run0.out
# mpirun --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_2ranks_run1.out
# 
# #  2 2 ranks
# mpirun --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_2ranks_run0.out
# mpirun --np 2 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_2ranks_run1.out
# 
# #  0 4 ranks
# mpirun --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_4ranks_run0.out
# mpirun --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_4ranks_run1.out
# 
# #  1 4 ranks
# mpirun --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_4ranks_run0.out
# mpirun --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_4ranks_run1.out
# 
# #  2 4 ranks
# mpirun --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_4ranks_run0.out
# mpirun --np 4 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_4ranks_run1.out
# 
# #  0 8 ranks
# mpirun --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_8ranks_run0.out
# mpirun --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_8ranks_run1.out
# 
# #  1 8 ranks
# mpirun --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_8ranks_run0.out
# mpirun --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_8ranks_run1.out
# 
# #  2 8 ranks
# mpirun --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_8ranks_run0.out
# mpirun --np 8 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_8ranks_run1.out
# 
# #  0 16 ranks
# mpirun --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_16ranks_run0.out
# mpirun --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_16ranks_run1.out
# 
# #  1 16 ranks
# mpirun --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_16ranks_run0.out
# mpirun --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_16ranks_run1.out
# 
# #  2 16 ranks
# mpirun --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_16ranks_run0.out
# mpirun --np 16 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_16ranks_run1.out
# 
# #  0 32 ranks
# mpirun --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_32ranks_run0.out
# mpirun --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_32ranks_run1.out
# 
# #  1 32 ranks
# mpirun --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_32ranks_run0.out
# mpirun --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_32ranks_run1.out
# 
# #  2 32 ranks
# mpirun --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_32ranks_run0.out
# mpirun --np 32 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_32ranks_run1.out
# 
# #  0 64 ranks
# mpirun --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_64ranks_run0.out
# mpirun --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_64ranks_run1.out
# 
# #  1 64 ranks
# mpirun --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_64ranks_run0.out
# mpirun --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_64ranks_run1.out
# 
# #  2 64 ranks
# mpirun --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_64ranks_run0.out
# mpirun --np 64 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_64ranks_run1.out
# 
# #  0 128 ranks
# mpirun --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_128ranks_run0.out
# mpirun --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_128ranks_run1.out
# 
# #  1 128 ranks
# mpirun --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_128ranks_run0.out
# mpirun --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_128ranks_run1.out
# 
# #  2 128 ranks
# mpirun --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_128ranks_run0.out
# mpirun --np 128 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_128ranks_run1.out
# 
# #  0 256 ranks
# mpirun --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_256ranks_run0.out
# mpirun --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_256ranks_run1.out
# 
# #  1 256 ranks
# mpirun --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_256ranks_run0.out
# mpirun --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_256ranks_run1.out
# 
# #  2 256 ranks
# mpirun --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_256ranks_run0.out
# mpirun --np 256 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_256ranks_run1.out
# 
# #  0 512 ranks
# mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_512ranks_run0.out
# mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_512ranks_run1.out
# 
# #  1 512 ranks
# mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_512ranks_run0.out
# mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_512ranks_run1.out
# 
# #  2 512 ranks
# mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_512ranks_run0.out
# mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_512ranks_run1.out
# 
# #  0 1024 ranks
# mpirun --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_1024ranks_run0.out
# mpirun --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_1024ranks_run1.out
# 
# #  1 1024 ranks
# mpirun --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_1024ranks_run0.out
mpirun --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_1024ranks_run1.out

#  2 1024 ranks
mpirun --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_1024ranks_run0.out
mpirun --np 1024 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_1024ranks_run1.out

#  0 2048 ranks
mpirun --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_2048ranks_run0.out
mpirun --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/0_2048ranks_run1.out

#  1 2048 ranks
mpirun --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_2048ranks_run0.out
mpirun --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/1_2048ranks_run1.out

#  2 2048 ranks
mpirun --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_2048ranks_run0.out
mpirun --np 2048 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoallv_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoallv >& /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-collectives-tuning/output/alltoallv/2_2048ranks_run1.out


# TJN: HACK avoid problems with broken --nolocal/:NOLOCAL
rm -f $MY_HOSTFILE

