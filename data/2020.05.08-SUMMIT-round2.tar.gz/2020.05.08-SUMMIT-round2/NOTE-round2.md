Note
====
 - TJN: The "ERROR" items in console log were actually not supposed
       to be resubmitted, thus the "IGNORE" marker.
       It appears they passed the first time and no need for a
       "Round2" resubmit.  The error was that I tried to run a script
       that did not exist (b/c I had already run it and did not restage.)



Console Log
===========

```
    Thu May  7 23:58:42 EDT 2020
    login1:$ ./SUMMIT-round2.sh
    + bsub -P STF010 ./output/allgather/allgather_coltune.sh
    Job <83931> is submitted to default queue <batch>.
    + bwait -w 'ended(allgather)'
    ended(allgather): Wait condition satisfied
    + bsub -P STF010 ./output/allgatherv/allgatherv_coltune.sh
    Job <84114> is submitted to default queue <batch>.
    + bwait -w 'ended(allgatherv)'
    ended(allgatherv): Wait condition satisfied
    + bsub -P STF010 ./output/allreduce/allreduce_coltune.sh
    ERROR: No walltime (-W) specified. Please resubmit with a walltime specification.
    ERROR: No nodes requested. Please request nodes with -nnodes.

    Typical usage:
            bsub [LSF arguments] jobscript
            bsub [LSF arguments] -Is $SHELL
            bsub -h[elp] [options]
            bsub -V

    NOTES:
     * All jobs must specify a walltime (-W) and project id (-P)
     * Standard jobs must specify a node count (-nnodes) or -ln_slots. These jobs cannot specify a reso
    urce string (-R).
     * Expert mode jobs (-csm y) must specify a resource string and cannot specify -nnodes or -ln_slots

     + bwait -w 'ended(allreduce)'
    allreduce: No matching job found
    + bsub -P STF010 ./output/alltoall/alltoall_coltune.sh
    Job <84247> is submitted to default queue <batch>.
    + bwait -w 'ended(alltoall)'
    ended(alltoall): Wait condition satisfied
    + bsub -P STF010 ./output/alltoallv/alltoallv_coltune.sh
    Job <84800> is submitted to default queue <batch>.
    + bwait -w 'ended(alltoallv)'
    ended(alltoallv): Wait condition satisfied
    + bsub -P STF010 ./output/barrier/barrier_coltune.sh
    ERROR: No walltime (-W) specified. Please resubmit with a walltime specification.
    ERROR: No nodes requested. Please request nodes with -nnodes.

    Typical usage:
            bsub [LSF arguments] jobscript
            bsub [LSF arguments] -Is $SHELL
            bsub -h[elp] [options]
            bsub -V

    NOTES:
     * All jobs must specify a walltime (-W) and project id (-P)
     * Standard jobs must specify a node count (-nnodes) or -ln_slots. These jobs cannot specify a reso
    urce string (-R).
     * Expert mode jobs (-csm y) must specify a resource string and cannot specify -nnodes or -ln_slots
    .
     + bwait -w 'ended(barrier)'
    barrier: No matching job found
    + bsub -P STF010 ./output/bcast/bcast_coltune.sh
    ERROR: No walltime (-W) specified. Please resubmit with a walltime specification.
    ERROR: No nodes requested. Please request nodes with -nnodes.

    Typical usage:
            bsub [LSF arguments] jobscript
            bsub [LSF arguments] -Is $SHELL
            bsub -h[elp] [options]
            bsub -V

    NOTES:
     * All jobs must specify a walltime (-W) and project id (-P)
     * Standard jobs must specify a node count (-nnodes) or -ln_slots. These jobs cannot specify a reso
    urce string (-R).
     * Expert mode jobs (-csm y) must specify a resource string and cannot specify -nnodes or -ln_slots
    .
     + bwait -w 'ended(bcast)'
    bcast: No matching job found
    + bsub -P STF010 ./output/gather/gather_coltune.sh
    ERROR: No walltime (-W) specified. Please resubmit with a walltime specification.
    ERROR: No nodes requested. Please request nodes with -nnodes.

    Typical usage:
            bsub [LSF arguments] jobscript
            bsub [LSF arguments] -Is $SHELL
            bsub -h[elp] [options]
            bsub -V

    NOTES:
     * All jobs must specify a walltime (-W) and project id (-P)
     * Standard jobs must specify a node count (-nnodes) or -ln_slots. These jobs cannot specify a reso
    urce string (-R).
     * Expert mode jobs (-csm y) must specify a resource string and cannot specify -nnodes or -ln_slots
    .
     + bwait -w 'ended(gather)'
    gather: No matching job found
    + bsub -P STF010 ./output/reduce/reduce_coltune.sh
    ERROR: No walltime (-W) specified. Please resubmit with a walltime specification.
    ERROR: No nodes requested. Please request nodes with -nnodes.

    Typical usage:
            bsub [LSF arguments] jobscript
            bsub [LSF arguments] -Is $SHELL
            bsub -h[elp] [options]
            bsub -V

    NOTES:
     * All jobs must specify a walltime (-W) and project id (-P)
     * Standard jobs must specify a node count (-nnodes) or -ln_slots. These jobs cannot specify a reso
    urce string (-R).
     * Expert mode jobs (-csm y) must specify a resource string and cannot specify -nnodes or -ln_slots
    .
     + bwait -w 'ended(reduce)'
    reduce: No matching job found
    + bsub -P STF010 ./output/reduce_scatter/reduce_scatter_coltune.sh
    ERROR: No walltime (-W) specified. Please resubmit with a walltime specification.
    ERROR: No nodes requested. Please request nodes with -nnodes.

    Typical usage:
            bsub [LSF arguments] jobscript
            bsub [LSF arguments] -Is $SHELL
            bsub -h[elp] [options]
            bsub -V

    NOTES:
     * All jobs must specify a walltime (-W) and project id (-P)
     * Standard jobs must specify a node count (-nnodes) or -ln_slots. These jobs cannot specify a reso
    urce string (-R).
     * Expert mode jobs (-csm y) must specify a resource string and cannot specify -nnodes or -ln_slots
    .
     + bwait -w 'ended(reduce_scatter)'
    reduce_scatter: No matching job found
    + bsub -P STF010 ./output/scatter/scatter_coltune.sh
    ERROR: No walltime (-W) specified. Please resubmit with a walltime specification.
    ERROR: No nodes requested. Please request nodes with -nnodes.

    Typical usage:
            bsub [LSF arguments] jobscript
            bsub [LSF arguments] -Is $SHELL
            bsub -h[elp] [options]
            bsub -V

    NOTES:
     * All jobs must specify a walltime (-W) and project id (-P)
     * Standard jobs must specify a node count (-nnodes) or -ln_slots. These jobs cannot specify a reso
    urce string (-R).
     * Expert mode jobs (-csm y) must specify a resource string and cannot specify -nnodes or -ln_slots
    .
     + bwait -w 'ended(scatter)'
    scatter: No matching job found
    + bsub -P STF010 ./output/reduce_scatter_block/reduce_scatter_block_coltune.sh
    Job <85385> is submitted to default queue <batch>.
    + bwait -w 'ended(reduce_scatter_block)'
    ended(reduce_scatter_block): Wait condition satisfied
    + python coltune_analyze.py example/config.summit.ppn42
    Error, cannot find file /gpfs/alpine/stf010/proj-shared/naughton/summit/ompix/perf-colltune/ompi-co
    llectives-tuning/output/allgather/0_2ranks_run0.out. Exiting..
    + echo 'Finished ROUND2 runs on SUMMIT'
    + mailx -s 'SUMMIT - ROUND2 coltune tests done' 3t4@ornl.gov
    login1:$ ls
```
