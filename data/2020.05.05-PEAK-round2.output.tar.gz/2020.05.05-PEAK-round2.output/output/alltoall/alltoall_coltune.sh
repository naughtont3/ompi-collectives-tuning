#!/bin/sh
#
#BSUB   -J alltoall
#BSUB   -o res.txt.%J
#BSUB   -e res.txt.%J
#BSUB   -W 2:00
#BSUB   -nnodes 13

module unload spectrum-mpi xalt darshan-runtime
module load gcc/6.4.0
module load cuda/10.1.243
module use /sw/summit/ums/ompix/DEVELOP/gcc/6.4.0/modules
module load ucx/1.7.0
module load openmpi/master_tjn

# TJN: HACK avoid problems with broken --nolocal/:NOLOCAL
export MY_HOSTFILE=/tmp/my-hostfile.$$
/gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/hack_fqn_nolocal_hostfile.sh $LSB_DJOB_HOSTFILE  $MY_HOSTFILE

#  0 512 ranks
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/0_512ranks_run0.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/0_512ranks_run1.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 0 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/0_512ranks_run2.out

#  1 512 ranks
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/1_512ranks_run0.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/1_512ranks_run1.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 1 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/1_512ranks_run2.out

#  2 512 ranks
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/2_512ranks_run0.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/2_512ranks_run1.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 2 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/2_512ranks_run2.out

#  3 512 ranks
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/3_512ranks_run0.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/3_512ranks_run1.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 3 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/3_512ranks_run2.out

#  4 512 ranks
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/4_512ranks_run0.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/4_512ranks_run1.out
mpirun --np 512 --hostfile $MY_HOSTFILE --map-by ppr:42:node --map-by core --mca coll_tuned_use_dynamic_rules 1 --mca coll_tuned_alltoall_algorithm 4 /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/OSU/osu-micro-benchmarks-5.6.2/_install/libexec/osu-micro-benchmarks/mpi/collective//osu_alltoall >& /gpfs/alpine/stf010/proj-shared/naughton/peak/ompix/perf-colltune/ompi-collectives-tuning/output/alltoall/4_512ranks_run2.out


# TJN: HACK avoid problems with broken --nolocal/:NOLOCAL
rm -f $MY_HOSTFILE

